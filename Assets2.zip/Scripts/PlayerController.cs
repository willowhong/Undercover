﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[System.Serializable]
public class Boundary
{
	public float xMin, xMax, zMin, zMax;
}


public class PlayerController : MonoBehaviour {

	private Rigidbody rb;
	public float speed;
	public Boundary boundary;


	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
		Vector3 movement = new Vector3 (moveHorizontal,0.0f, moveVertical);

		if (movement != Vector3.zero) {
			transform.rotation = Quaternion.LookRotation (movement);
		}

		transform.Translate (movement * speed * Time.deltaTime, Space.World);

		transform.position = new Vector3 (
			Mathf.Clamp (transform.position.x, boundary.xMin, boundary.xMax),
			0.0f,
			Mathf.Clamp (transform.position.z, boundary.zMin, boundary.zMax)
		);
	}
}




