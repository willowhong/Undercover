﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Freeze : MonoBehaviour {

	public AudioClip clip;
	public GameObject button;

	void Start(){
		button.SetActive (false);
	}

	void OnTriggerEnter(Collider other)
	{
		if (other.tag == "Boundary") {
			return;
		}


		if (other.tag == "Light") {
			AudioSource.PlayClipAtPoint (clip, new Vector3 (5, 1, 2));
			button.SetActive (true);

			if (Time.timeScale == 1.0F) {
				Time.timeScale = 0.001F;
			}
		}
	}
}
						