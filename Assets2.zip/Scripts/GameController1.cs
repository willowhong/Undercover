﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController1 : MonoBehaviour {
	public GameObject[] hazards;
	private List<GameObject> enemies;
	private GameObject Instance;
	private GameObject enemycontrol;
	public Transform spawnTransform;
	public int hazardCount;
	public float spawnWait;
	public float waveWait;
	private PlayerController controller;


	void Start ()
	{
		controller = GameObject.Find ("Player").GetComponent <PlayerController>();
		enemycontrol = GameObject.Find ("Game Controller");
		StartCoroutine (SpawnWaves ());
		enemies = new List<GameObject>();
		Screen.SetResolution(1440, 800, false);

	}

	IEnumerator SpawnWaves ()
	{
		while (true)
		{
			for (int i = 0; i < hazardCount; i++)
			{
				Vector3 offset = new Vector3 (0.0f, Random.Range (-1.0f, 1.0f), 0.0f);
				GameObject Instance = Instantiate (hazards[Random.Range(0, hazards.Length)], spawnTransform.position + offset, spawnTransform.rotation) as GameObject;
				yield return new WaitForSeconds (Random.Range(spawnWait-0.2f, spawnWait+0.2f));
				enemies.Add (Instance);
			}
			yield return new WaitForSeconds (waveWait);
		}
	}

	void Update () {
		if (controller.enabled == false) {
			foreach (GameObject enemy in enemies) {
				Destroy (enemy);
			}
		enemycontrol.SetActive (false);

		}
	}
}
	


