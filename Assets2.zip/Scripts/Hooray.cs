﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hooray : MonoBehaviour {

	public AudioClip clip;
	public GameObject button;
	private Collider collider;
	private PlayerController playercontrol;

	void Start(){
		collider = GetComponent<CapsuleCollider> ();
		playercontrol = GetComponent<PlayerController> ();
		button.SetActive (false);

	}

	IEnumerator RotateMe(Vector3 byAngles, float inTime){
		var fromAngle = transform.rotation;
		var toAngle = Quaternion.Euler(transform.eulerAngles + byAngles);
		for (var t = 0f; t <= 1; t += Time.deltaTime/inTime) {
			transform.rotation = Quaternion.Slerp(fromAngle, toAngle, t);
			yield return null;
		}
	}
		
	void OnTriggerEnter(Collider other)
	{
		if (other.tag == "Boundary") {
			return;
		}

		if (other.tag == "Endpoint") {
			AudioSource.PlayClipAtPoint (clip, new Vector3 (5, 1, 2));
			button.SetActive (true);
			collider.enabled = false;
			playercontrol.enabled = false;
			StartCoroutine(RotateMe(Vector3.up * 90, 0.3f));
			}
		}
		
}
