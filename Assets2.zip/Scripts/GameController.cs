﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour {

	public GameObject[] hazards;
	public Vector3 spawnValues;
	public int hazardCount;
	public float spawnWait;
	public float startWait;
	public float waveWait;

	void Start ()
	{
		StartCoroutine (SpawnWaves ());
	}

	IEnumerator SpawnWaves ()
	{
		yield return new WaitForSeconds (startWait);
		while (true)
		{
			for (int i = 0; i < hazardCount; i++)
			{
				Vector3 spawnPosition = new Vector3 (spawnValues.x,Random.Range (spawnValues.y, 2 + spawnValues.y), spawnValues.z);
				Quaternion spawnRotation = Quaternion.Euler(0,90,0);
				Instantiate (hazards[Random.Range(0, hazards.Length)],spawnPosition, spawnRotation);

				yield return new WaitForSeconds (Random.Range(spawnWait-1, spawnWait+1));
			}
			yield return new WaitForSeconds (waveWait);
		}
	}
}