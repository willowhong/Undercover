﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightController : MonoBehaviour {

	public float waitTime;
	private float Timer;
	private float ResetPoint;
	Renderer renderLight;
	Collider colliderLight;

	void Start(){
		Timer = 0.0f;
		ResetPoint = 2 * waitTime;
		renderLight = GetComponent<Renderer>();
		colliderLight = GetComponent<Collider>();

	}

	void Update(){

		Timer += Time.deltaTime;

		if(Timer < waitTime)
		{
			renderLight.enabled = true;
			colliderLight.enabled = true;
		}

		if(Timer > waitTime)
		{
			renderLight.enabled = false;
			colliderLight.enabled = false;
		}

		if(Timer > ResetPoint)
		{
			Timer = 0.0f;

		}

	}
}